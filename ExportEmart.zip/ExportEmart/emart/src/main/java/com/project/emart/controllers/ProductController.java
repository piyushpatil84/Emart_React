package com.project.emart.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.emart.Service.ProductService;
import com.project.emart.dao.Product;

@RestController
@RequestMapping("/product")
@CrossOrigin()
public class ProductController {
	
	@Autowired
	private ProductService ps;
	
	@GetMapping("/sample")
	public Product addSample() {
		Product product = new Product("Laptop1", 1000.0, 1, "sample", "Laptop", "Behetrin product");
		return ps.addNewProduct(product);
	}
	
	@GetMapping
	public List<Product> getAllProduct(){
		return ps.getAllProducts();
	}

	@GetMapping("/byCategory/{category}")
	public List<Product> getAllProductByCate(@PathVariable("category") String category){
		return ps.getProductByCategory(category);
	} 
	
	@PostMapping
	public Product addNewProduct(@RequestBody Product product) {
		return ps.addNewProduct(product);
	}
	
	@GetMapping("/{id}")
	public Product getProduct(@PathVariable("id") Long id) {
		return ps.getProductByID(id);
	}
	
	@DeleteMapping("/remove/{id}")
	public Product deleteProduct(@PathVariable("id") Long id) {
		Product product = ps.getProductByID(id);
		ps.deleteProduct(product);
		return product;
	}
}
