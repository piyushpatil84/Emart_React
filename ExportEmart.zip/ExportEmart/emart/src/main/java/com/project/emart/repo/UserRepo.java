package com.project.emart.repo;

import org.springframework.data.repository.CrudRepository;

import com.project.emart.dao.UserDao;

public interface UserRepo extends CrudRepository<UserDao, Long> {

	public UserDao findByUserName(String userName);
}
