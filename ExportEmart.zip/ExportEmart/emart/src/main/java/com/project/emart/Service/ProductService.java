package com.project.emart.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.emart.dao.Product;
import com.project.emart.repo.ProductRepo;

@Service
public class ProductService {

	@Autowired
	private ProductRepo productRepo;
	
	
	public Product getProductByID(Long id) {
		return productRepo.findById(id).get();
	}
	
	public List<Product> getProductByCategory(String category) {
		return productRepo.findByCategory(category);
	}
	
	public void deleteProduct(Product product) {
		productRepo.deleteById(product.getId());
		
	}
	
	public Product addNewProduct(Product product) {
		return productRepo.save(product);
	}
	
	public List<Product> getAllProducts() {
		return (List<Product>) productRepo.findAll();
	}
}
