package com.project.emart.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.project.emart.dao.Product;

public interface ProductRepo extends CrudRepository<Product, Long> {
	
	public List<Product> findByCategory(String category);

}
