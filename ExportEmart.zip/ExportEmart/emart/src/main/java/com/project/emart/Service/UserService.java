package com.project.emart.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.emart.dao.UserDao;
import com.project.emart.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;
	
	public UserDao addNewUser(UserDao user) {
		try {
			return userRepo.save(user); 
		}catch (Exception e) {
			throw new RuntimeException("User with this name already exist");
		}	
	}
		
	public UserDao updateUser(UserDao user) {
		Optional<UserDao> userNew = userRepo.findById(user.getId());
		return userRepo.save(user);
	}
	
	public UserDao getUserByName(String userName) {
		System.out.println("Inside service method");
		try {
			return userRepo.findByUserName(userName);
		}catch (Exception e) {
			throw new RuntimeException("Incorrect UserName");
		}
		
	}
	
	public List<UserDao> getAllUser(){
		return (List<UserDao>) userRepo.findAll();
	}
}
