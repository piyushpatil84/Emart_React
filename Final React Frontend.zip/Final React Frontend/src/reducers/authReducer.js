import {AUTH_FETCH} from '../action/types'

const initialState ={
    userName:"",
    Role:""
}

export default function (state=initialState,action){
    switch(action.type){
        case AUTH_FETCH : return {
            userName :action.payload.userName,
            Role :action.payload.Role
        }
        default :
        return state
    }
}