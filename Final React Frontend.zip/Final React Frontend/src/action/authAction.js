import {AUTH_FETCH} from './types'
export const authfetch = (data) =>dispatch=>{
    dispatch({
          type:AUTH_FETCH,
          payload:{userName:data.userName,Role:data.Role}
    })
}